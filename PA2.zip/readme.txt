Yu Feng (fengy@gatech.edu)
Cameron Gallahue (cgallahue3@gatech.edu)
Programming Assignment 2
4/17/16

ftaclient.py		file transfer client
ftaserver.py		file transfer server
dbengineRTP.py		database server
dbclientRTP.py		database client
RTP.py				RTP protocol program
sample.txt			sample command for running the program
RTP Protocal Design Documentation.pdf	Complete Design Report
3251.jpg			picture of a white cow, usecd for testing file transfer

Please see sample.txt for a sample of how to run the program.
Please see RTP Protocal Design Documentation.pdf for the complete design report.